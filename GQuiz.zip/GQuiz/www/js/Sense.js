// Timer
var i = 0;
function move() {
  if (i == 0) {
    i = 1;
    var elem = document.getElementById("myBar");
    var width = 90;
    var id = setInterval(frame, 1000);
    var secleft = 30;
    function frame() {
      if (width <= 0) {
        clearInterval(id);
        i = 0;
      } else {
        width -= 3;
        secleft--;
        elem.style.width = width + "%";
        elem.innerHTML = secleft;
        if (secleft == 0) {
        showScores();
        }
      }
    }
  }
}

// quiz
function populate() {
    if(quiz.isEnded()) {
        showScores();
        document.getElementById("myBar").style.display = "none";
    }
    else {
        // show question
        var element = document.getElementById("question");
        element.innerHTML = quiz.getQuestionIndex().text;

        // show options
        var choices = quiz.getQuestionIndex().choices;
        for(var i = 0; i < choices.length; i++) {
            var element = document.getElementById("choice" + i);
            element.innerHTML = choices[i];
            guess("btn" + i, choices[i]);
        }
        showProgress();
    }
};

function skip() {
    document.getElementsByClassName('skip')[0].disabled = true;
    quiz.guess(guess);
    quiz.score += 2;
    populate();
};

function guess(id, guess) {
    var button = document.getElementById(id);
    button.onclick = function() {
        quiz.guess(guess);
        populate();
    }
};

function showProgress() {
    var currentQuestionNumber = quiz.questionIndex + 1;
    var element = document.getElementById("progress");
    element.innerHTML = "Question " + currentQuestionNumber + " of " + quiz.questions.length;
};

function showScores() {
    var gameOverHTML = "<h1>Result</h1>";
    gameOverHTML += "<h2 id='score'> You scored: " + quiz.score + "</h2>";
    var element = document.getElementById("questions");
    element.innerHTML = gameOverHTML;
};

// Questions
var questions = [
    new Question("The angle between the minute hand and the hour hand of a clock when the time is 8.30, is", ["65", "75","85", "90"], "75"),
    new Question("1, 4, 8, 13, ?, 26", ["15", "19", "20", "21"], "19"),
    new Question("Manager : Assistant :: Doctor : ?", ["Chemist", "Nurse","Patient", "Medicines"], "Nurse"),
    new Question("A Boy walks 12kms towards east. He turns 90° clockwise and walks 20kms then he turned right and walked for 33kms. How far is he from starting point?", ["65", "29", "21", "43"], "29"),
    new Question("8, 10, 12, 14, ?", ["18", "15", "26", "16"], "16"),
    new Question("C is the father of D. But D is not the son of C. How is that possible?", ["D is C's daughter", "C is D's uncle", "Both are brothers", "They are not related"], "D is C's daughter"),
    new Question("How can a man go 9 days without sleep?", ["magic", "surgery", "by sleeping during the night", "It's impossible"], "by sleeping during the night"),
    new Question("Which is heavier: 100 pounds of steel or 100 pounds of feathers?", ["steel", "feathers", "They weigh the same", "Neither weighs anything"], "They weigh the same"),
    new Question("Before Mount Everest was discovered, what was the highest mountain on earth?", ["Mt. Vesuvius", "Mt. Everest", "Mt. Carmel", "Mt. McKinley"], "Mt. Everest"),
    new Question("Rain Gauge: Rain :: ? : Humidity", ["Odometer", "Seismograph", "Hygrometer", "None of the above"], "Seismograph")
];

// create quiz
var quiz = new Quiz(questions);
// display quiz
populate();