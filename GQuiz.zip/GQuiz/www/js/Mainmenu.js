function geek() {
	window.location.href = "Geek.html";
}

function past() {
	window.location.href = "Past.html";
}

function paws() {
	window.location.href = "Paws.html";
}

function equations() {
	window.location.href = "Equations.html";
}

function sense() {
	window.location.href = "Sense.html";
}